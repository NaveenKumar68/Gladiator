package stepdefinition;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.When;
import pages.HomePageAction;
import pages.LoginPageAction;
import utility.Base;

public class LoginPageStepDefinition extends Base{
	
	public static ExtentReports reports=Hooks.reports;
    public static ExtentTest test=HomePageAction.test;
    LoginPageAction lpAction =new LoginPageAction(driver, test);

	@When("enters valid credentials")
	public void enters_valid_credentials() {
	    lpAction.validLogin();
	}

	@When("enters invalid credentials")
	public void enters_invalid_credentials() {
	    lpAction.inValidLogin();
	}
}
