package stepdefinition;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.DeliveryInformationPageAction;
import pages.HomePageAction;
import utility.Base;


public class DeliveryInformationPageStepDefinition extends Base{
	public static ExtentReports reports=Hooks.reports;
    public static ExtentTest test=HomePageAction.test;
    DeliveryInformationPageAction dPageAction=new DeliveryInformationPageAction(driver, test);
    
    @Then("the Delivery Chart should be displayed")
	public void the_delivery_chart_should_be_displayed() {
		dPageAction.deliveryChart();
	}

	@Then("the user should be able to click on Blue Dart delivery option")
	public void the_user_should_be_able_to_click_on_blue_dart_delivery_option() {
		dPageAction.clickBlueDart();
	}

}
