package stepdefinition;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.BrandPageAction;
import pages.HomePageAction;
import utility.Base;

public class BrandPageStepDefinition extends Base{
    public static ExtentReports reports=Hooks.reports;
    public static ExtentTest test=HomePageAction.test;
    BrandPageAction bPageAction=new BrandPageAction(driver, test);
    
    @When("Click on the desired Brand1")
    public void click_on_the_desired_brand1() {
        bPageAction.clickNike();
    }
    @When("Verify the brand1")
    public void verify_the_brand1() {
        bPageAction.verifyNike();
    }
	@When("Click on the alphabetic button to filter the brands")
	public void click_on_the_alphabetic_button_to_filter_the_brands() {
	    bPageAction.clickA();
	}
	@When("Click on the desired Brand2")
    public void click_on_the_desired_brand2() {
        bPageAction.clickAlpha();
    }
    @Then("Verify the brand2")
    public void verify_the_brand2() {
        bPageAction.verifyAlpha();;
    }
    @When("Click on the Numeric button to filter the brands")
    public void click_on_the_numeric_button_to_filter_the_brands() {
		bPageAction.clickNumeric();
    }

    @Then("Verify Error message is displayed")
    public void verify_error_message_is_displayed() {
        bPageAction.verifyNumberic();
    }
    @Then("Verify the desired brand")
    public void verify_the_desired_brand() {
    	bPageAction.wildCraft();
    }
}
