package stepdefinition;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageAction;
import utility.Base;

public class HomePageStepDefinition extends Base{
	public static ExtentReports reports=Hooks.reports;
    public static ExtentTest test=HomePageAction.test;
    HomePageAction hpAction =new HomePageAction(driver, test);
    int c=0;
    @Given("The user is on the homepage")
    public void the_user_is_on_the_homepage() {
    	c++;
    	reports=Hooks.reports;
    	test=reports.createTest("Test"+c);
    	hpAction=new HomePageAction(driver, test);
    }
    @When("The user enters product in the search bar")
    public void the_user_enters_product_in_the_search_bar() {
    	hpAction.locateSearchBar();
    }
    @When("The user clicks on brand in the navigation bar")
    public void the_user_clicks_on_brand_in_the_navigation_bar() {
        hpAction.clickBrand();
    }
    @When("Clicks the search button")
    public void clicks_the_search_button() {
    	hpAction.clickSearchBtn1();
    }
    @Then("Verify the products should be displayed")
    public void verify_the_products_should_be_displayed() {
    	hpAction.verify();
    }
	@When("The user enters Special Characters in the search bar")
	public void the_user_enters_special_characters_in_the_search_bar() {
		hpAction.locateSearchBar();
	}
	@Then("Verify no products should be shown")
	public void verify_no_products_should_be_shown() {
		hpAction.clickSearchBtn2();
	}
	@When("Scroll to moving brand")
    public void scroll_to_moving_brand() {
    	hpAction.scrollToWildCraft();
    }
	@When("Click on the brand")
    public void click_on_the_brand() {
        hpAction.clickWildCraft();
    }
	@Then("the system should display the best-selling products")
	public void the_system_should_display_the_best_selling_products() {
		hpAction.bestSeller();
	}
	@Then("the Just In section should be displayed when accessed")
	public void the_just_in_section_should_be_displayed_when_accessed() {
		hpAction.justIn();
	}

	@Then("the Exclusive section should be displayed when accessed")
	public void the_exclusive_section_should_be_displayed_when_accessed() {
		hpAction.exclusive();
	}

	@Then("the Best Deals section should be displayed when accessed")
	public void the_best_deals_section_should_be_displayed_when_accessed() {
		hpAction.bestDeals();
	}
	@When("the user clicks on the login button")
	public void the_user_clicks_on_the_login_button() {
		hpAction.clickLogin();
	}

	@Then("the user should be successfully logged in")
	public void the_user_should_be_successfully_logged_in() {
	    // You can add verification logic here if needed
	    System.out.println("User logged in successfully.");
	}

	@Then("able to access the My Orders section")
	public void able_to_access_the_my_orders_section() {
		hpAction.clickMyOrders();
	}
	@Then("the user should be successfully logged in and able to access the My Orders section")
	public void the_user_should_be_successfully_logged_in_and_able_to_access_the_my_orders_section() {
	    
	}

	@Then("the user should see a login error and should not be able to access the My Orders section")
	public void the_user_should_see_a_login_error_and_should_not_be_able_to_access_the_my_orders_section() {
	    
	}
	
	@When("the user clicks on Delivery Charges")
	public void the_user_clicks_on_delivery_charges() {
    	hpAction.clickDeliveryCharges();
	}


}
