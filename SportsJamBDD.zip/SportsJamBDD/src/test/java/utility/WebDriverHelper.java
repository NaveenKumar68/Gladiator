package utility;


import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverHelper {
    public WebDriver driver;
    Actions action;
    JavascriptExecutor js;

    public WebDriverHelper(WebDriver driver) {
        this.driver = driver;
        action = new Actions(driver);
        js = (JavascriptExecutor) driver;
    }

    /*
     * Method Name: click_btn
     * Author Name: Naveen Kumar
     * Description: Click on an Element.
     * Return type: void
     * Parameters: By
     */
    public void clickOnElement(By locator) {
        driver.findElement(locator).click();
    }

    /*
     * Method Name: switchWin
     * Author Name: Naveen Kumar
     * Description: Switch the focus to one window to another.
     * Return type: void
     * Parameters: none
     */
    public void switchWin() {
        String parent = driver.getWindowHandle();
        Set<String> allWIndows = driver.getWindowHandles();
        for (String child : allWIndows) {
            if (!child.equals(parent)) {
                driver.switchTo().window(child);
                break;
            }
        }
    }

    /*
     * Method Name: sendKey
     * Author Name: Naveen Kumar
     * Description: Send values
     * Return type: By,String
     * Parameters: Void
     */
    public void sendKey(By locator, String str) {
        driver.findElement(locator).sendKeys(str);
    }

    /*
     * Method Name: jsScroll
     * Author Name: Naveen Kumar
     * Description: scroll to target webElement.
     * Return type: void
     * Parameters: By
     */
    public void jsScroll(By locator) {
        js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(locator));
    }

    /*
     * Method Name: HoverElement
     * Author Name: Naveen Kumar
     * Description: Hover over the Element.
     * Return type: void
     * Parameters: By
     */
    public void hoverOverElement(By locator) {
        action.moveToElement(driver.findElement(locator)).build().perform();
    }

    /*
     * Method Name: actionClick
     * Author Name: Krithika
     * Description: Action Click.
     * Return type: void
     * Parameters: By
     */
    public void actionClick(By locator) {
        action.moveToElement(driver.findElement(locator)).click().build().perform();
    }

    /*
     * Method Name: dropDown
     * Author Name: Naveen Kumar
     * Description: select by value from dropdown.
     * Return type: void
     * Parameters: By, String
     */
    public void dropDown(By locator, String val) {
        WebElement dropDown = driver.findElement(locator);
        Select select = new Select(dropDown);
        select.selectByValue(val);
    }
    /*
     * Method Name: waitForElementToBeClick
     * Author Name: Naveen Kumar
     * Description: Explicit wait to wait for an element to be clickable.
     * Return type: void
     * Parameters: By, int
     */

    public void waitForElementToBeClick(By locator, int timeoutInSeconds) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds))
                    .until(ExpectedConditions.elementToBeClickable(locator));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Method Name: waitForElementToBeVisible
     * Author Name: Naveen Kumar
     * Description: Explicit wait to wait for an element to be visible.
     * Return type: void
     * Parameters: By, int
     */
    public void waitForElementToBeVisible(By locator, int timeoutInSeconds) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds))
                    .until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Method Name: isDisplayed
     * Author Name: Naveen Kumar
     * Description: check if the element is displayed or not.
     * Return type: Boolean
     * Parameters: By
     */
    public Boolean isDisplayed(By loc) {
        WebElement element = driver.findElement(loc);
        return element.isDisplayed();
    }


    /*
     * Method Name: jsClick
     * Author Name: Naveen Kumar
     * Description: click on the element.
     * Return type: void
     * Parameters: By
     */
    public void jsClick(By loc) {
        js.executeScript("arguments[0].click()", driver.findElement(loc));
    }

    /*
     * Method Name: navigateBack
     * Author Name: Naveen Kumar
     * Description: navigate back to the page.
     * Return type: void
     * Parameters: none
     */
    public void navigateBack() {
        driver.navigate().back();
    }

    /*
     * Method Name: countFilters
     * Author Name: Naveen Kumar
     * Description: count number of elements in the selected filters.
     * Return type: void
     * Parameters: By
     */
    public int countFilters(String loc) {
        List<WebElement> list = driver.findElements(By.xpath(loc));
        return list.size();
    }

    /*
     * Method Name: getURL
     * Author: Vipin Kanna V I
     * Description: Retrieves the current URL of the page.
     * Return Type: String
     * Parameters: none
     */
    public String getURL() {
        return driver.getCurrentUrl();
    }


    


    /**
     * Method Name: assertVerify
     * Author: Vipin Kanna V I
     * Description: Asserts that the actual string contains the expected string.
     * Return Type: void
     * Parameters: String actual, String expected
     */
    public void verify(String actual, String expected) {
        try {
            Assert.assertEquals(expected, actual);
        } catch (AssertionError e) {
            System.out.println("Verification failed: " + actual + " vs " + expected);
        }
    }

    /*
     * Method Name: getText
     * Author: Vipin Kanna V I
     * Description: Retrieves the text of a web element located by the given locator.
     * Return Type: String
     * Parameters: By locator
     */
    public String getText(By locator) {
        return driver.findElement(locator).getText();
    }

    /**
     * Method Name: switchToIFrame
     * Author: Vipin Kanna V I
     * Description: Switches the WebDriver context to the specified iframe.
     * Return Type: void
     * Parameters: By locator
     */
    public void switchToIFrame(By locator) {
        WebElement iframeElement = driver.findElement(locator);
        driver.switchTo().frame(iframeElement);
    }

    /*
     * Method Name: switchBackFromIframe
     * Author: Vipin Kanna V I
     * Description: Switches the WebDriver context back to the default content from an iframe.
     * Return Type: void
     * Parameters: none
     */
    public void switchBackFromIframe() {
        driver.switchTo().defaultContent();
    }
    public int getElementByXPath(String path){
    	List<WebElement> list=driver.findElements(By.xpath(path));
    	int size=list.size();
    	for(WebElement i:list) {
    		System.out.print(i.getText()+"--->");
    	}
    	return size;
    }
    public List<WebElement> getElementByXPath(By loc){
    	List<WebElement> list=driver.findElements(loc);
    	for(WebElement i: list) {
    		String string=i.getText();
    		System.out.print(string+" ");
    	}
    	return list;
    }

}
