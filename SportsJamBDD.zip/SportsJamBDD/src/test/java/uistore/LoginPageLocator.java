package uistore;

import org.openqa.selenium.By;

public class LoginPageLocator {
	public static By email=By.id("email");
    public static By pwd=By.id("pass");
    public static By clickSignin=By.xpath("//span[text()='Sign In']");
    public static By hoverCartBy=By.xpath("//a[@class='action showcart']");
}
