package uistore;

import org.openqa.selenium.By;

public class deliveryInformationPageLocator {
	public static By verifyChart=By.xpath("//table/tbody/tr/td");
	public static By clickBlueDartBy=By.xpath("//a[text()='Click for online tracking of Blue Dart']");
	
}
