package uistore;

import org.openqa.selenium.By;

public class HomePageLocator {
	public static By clickSearchBtnBy=By.xpath("//span[@class='search-icon-wrapper']");
	public static By clickSearchBarBy=By.id("search");
	public static By clickGoBy=By.xpath("//span[text()='Go']");
	public static By errorMessageBy=By.xpath("//div[@class='message notice']/div");
	
	//Testcase3
	public static By clickBrandBy=By.xpath("//span[text()='Brand']");
	
	//TestCase6
	public static By clickWildCraftByte=By.xpath("//img[@title='Wildcraft']");
	
	//TestCase7
	public static String getAllBSProductsBy="//div[@class='owl-stage']//strong[@class='product-item-name']/a";
	public static By clickBestSellerBy=By.xpath("(//ul[@class='ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all']/li)[1]/a");
	public static By clickJustInBy=By.xpath("(//ul[@class='ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all']/li)[2]/a");
	public static By clickExclusiveBy=By.xpath("(//ul[@class='ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all']/li)[3]/a");
	public static By clickBestDealsBy=By.xpath("(//ul[@class='ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all']/li)[4]/a");
	
	//testCase11
	public static By hoverUserIcon=By.xpath("//a[@class='button js-item-myaccount-action']/i");
	public static By myOrder=By.xpath("//a[text()='My Orders']");
	
    public static By clickLoginBy=By.xpath("//a[text()='Log In']");
    
	
    
    //testCase13
    public static By clickDeliverCharges=By.xpath("//a[text()='Delivery & Charges']");
}
