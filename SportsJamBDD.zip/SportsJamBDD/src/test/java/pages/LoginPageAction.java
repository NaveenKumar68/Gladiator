package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import uistore.HomePageLocator;
import uistore.LoginPageLocator;
import utility.LoggerHandler;
import utility.Reporter;
import utility.Screenshot;
import utility.WebDriverHelper;

public class LoginPageAction {
	public static WebDriver driver;
    public static ExtentReports reports;
    public static ExtentTest test;
    public static WebDriverHelper helper;

    /**
     * Constructor to initialize WebDriver and ExtentTest instances.
     * @param driver WebDriver instance
     * @param test ExtentTest instance for reporting
     */
    public LoginPageAction(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test = test;
        helper = new WebDriverHelper(driver);
    }
    
    /*
     * Method Name: validLogin
     * Author Name: Naveen Kumar
     * Description: Performs valid login using hardcoded credentials and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void validLogin() {
        try {
            
            helper.clickOnElement(LoginPageLocator.email);
            helper.sendKey(LoginPageLocator.email, "naveen123@gmail.com");
            helper.clickOnElement(LoginPageLocator.pwd);
            helper.sendKey(LoginPageLocator.pwd, "Naveen.k@2003");
            helper.hoverOverElement(LoginPageLocator.clickSignin);
            helper.clickOnElement(LoginPageLocator.clickSignin);
            Thread.sleep(2000);
            helper.hoverOverElement(LoginPageLocator.hoverCartBy);
            Screenshot.captureScreenshotTimeStamp(driver);
            LoggerHandler.info("Valid login performed successfully");
            test.info("Valid login performed successfully");
        } catch (Exception e) {
            LoggerHandler.error("Error during valid login: " + e.getMessage());
            test.fail("Error during valid login");
            Reporter.attachScreenShotToReport(test,driver,"Valid login failed");
        }
    }

    /*
     * Method Name: inValidLogin
     * Author Name: Naveen Kumar
     * Description: Attempts login with invalid credentials and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void inValidLogin() {
        try {
            helper.clickOnElement(LoginPageLocator.email);
            helper.sendKey(LoginPageLocator.email, "naveen1234@gmail.com");
            helper.clickOnElement(LoginPageLocator.pwd);
            helper.sendKey(LoginPageLocator.pwd, "Naveen.k@2003");
            helper.hoverOverElement(LoginPageLocator.clickSignin);
            helper.clickOnElement(LoginPageLocator.clickSignin);
            Thread.sleep(2000);
            helper.hoverOverElement(LoginPageLocator.hoverCartBy);
            Screenshot.captureScreenshotTimeStamp(driver);
            LoggerHandler.info("Invalid login attempt completed");
            test.info("Invalid login attempt completed");
        } catch (Exception e) {
            LoggerHandler.error("Error during invalid login: " + e.getMessage());
            test.fail("Error during invalid login");
            Reporter.attachScreenShotToReport(test,driver,"Invalid login failed");
        }
    }
}
