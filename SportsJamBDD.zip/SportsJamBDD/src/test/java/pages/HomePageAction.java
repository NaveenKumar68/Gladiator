package pages;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import uistore.HomePageLocator;
import utility.ExcelReader;
import utility.LoggerHandler;
import utility.Reporter;
import utility.Screenshot;
import utility.WebDriverHelper;

public class HomePageAction {
    public static WebDriver driver;
    public static ExtentReports reports;
    public static ExtentTest test;
    public static WebDriverHelper helper;

    /**
     * Constructor to initialize WebDriver and ExtentTest instances.
     * @param driver WebDriver instance
     * @param test ExtentTest instance for reporting
     */
    public HomePageAction(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test = test;
        helper = new WebDriverHelper(driver);
    }

    /*
     * Method Name: locateSearchBar
     * Author Name: Naveen Kumar
     * Description: Locates and verifies the visibility of the search bar
     * Return type: void
     * Parameters: void
     */
    public void locateSearchBar() {
        try {
            helper.waitForElementToBeVisible(HomePageLocator.clickSearchBtnBy, 5);
            helper.clickOnElement(HomePageLocator.clickSearchBtnBy);
            helper.waitForElementToBeVisible(HomePageLocator.clickSearchBarBy, 5);
            if (helper.isDisplayed(HomePageLocator.clickSearchBarBy)) {
                System.out.println("Search Bar is displayed");
                LoggerHandler.info("Search Bar is displayed");
                test.info("Search Bar is displayed");
            } else {
                System.out.println("Search Bar is not displayed");
                LoggerHandler.info("Search Bar is not displayed");
                test.info("Search Bar is not displayed");
            }
        } catch (Exception e) {
            LoggerHandler.error("Error locating search bar: " + e.getMessage());
            test.fail("Error locating search bar");
        }
    }

    /*
     * Method Name: clickSearchBtn1
     * Author Name: Naveen Kumar
     * Description: Clicks search bar, enters data from Excel, and clicks Go
     * Return type: void
     * Parameters: void
     */
    public void clickSearchBtn1() {
        try {
            helper.waitForElementToBeVisible(HomePageLocator.clickSearchBarBy, 5);
            helper.clickOnElement(HomePageLocator.clickSearchBarBy);
            LoggerHandler.info("Clicked search bar");
//            String string = ExcelReader.readData("./testdata/data.xlsx", "Sheet1", 0, 0);
            helper.sendKey(HomePageLocator.clickSearchBarBy, "Shoes");
            helper.waitForElementToBeVisible(HomePageLocator.clickGoBy, 5);
            helper.hoverOverElement(HomePageLocator.clickGoBy);
            helper.clickOnElement(HomePageLocator.clickGoBy);
            Thread.sleep(3000);
        } catch (Exception e) {
            LoggerHandler.error("Error in clickSearchBtn1: " + e.getMessage());
            test.fail("Error in clickSearchBtn1");
        }
    }

    /*
     * Method Name: clickSearchBtn2
     * Author Name: Naveen Kumar
     * Description: Clicks search bar, enters invalid data, verifies error message
     * Return type: void
     * Parameters: void
     */
    public void clickSearchBtn2() {
        try {
            helper.waitForElementToBeVisible(HomePageLocator.clickSearchBarBy, 5);
            helper.clickOnElement(HomePageLocator.clickSearchBarBy);
            LoggerHandler.info("Clicked search bar");
//            String string = ExcelReader.readData("./testdata/data.xlsx", "Sheet1", 0, 1);
            helper.sendKey(HomePageLocator.clickSearchBarBy, "@#$%^&*");
            helper.waitForElementToBeVisible(HomePageLocator.clickGoBy, 5);
            helper.hoverOverElement(HomePageLocator.clickGoBy);
            helper.clickOnElement(HomePageLocator.clickGoBy);
            Thread.sleep(3000);
            String curString = driver.findElement(HomePageLocator.errorMessageBy).getText();
            helper.verify("NO RESULTS", curString);
            Screenshot.captureScreenshotTimeStamp(driver);
        } catch (Exception e) {
            LoggerHandler.error("Error in clickSearchBtn2: " + e.getMessage());
            test.fail("Error in clickSearchBtn2");
        }
    }

    /*
     * Method Name: verify
     * Author Name: Naveen Kumar
     * Description: Verifies the page title contains "Shoes"
     * Return type: void
     * Parameters: void
     */
    public void verify() {
        try {
            String cur = driver.getTitle().toString();
            System.out.println(cur);
            helper.verify("Shoes", cur);
        } catch (Exception e) {
            LoggerHandler.error("Error verifying title: " + e.getMessage());
            test.fail("Error verifying title");
        }
    }

    /*
     * Method Name: clickBrand
     * Author Name: Naveen Kumar
     * Description: Clicks on the brand section
     * Return type: void
     * Parameters: void
     */
    public void clickBrand() {
        try {
            helper.hoverOverElement(HomePageLocator.clickBrandBy);
            helper.clickOnElement(HomePageLocator.clickBrandBy);
        } catch (Exception e) {
            LoggerHandler.error("Error clicking brand: " + e.getMessage());
            test.fail("Error clicking brand");
        }
    }

    /*
     * Method Name: clickWildCraft
     * Author Name: Naveen Kumar
     * Description: Scrolls and clicks on WildCraft brand
     * Return type: void
     * Parameters: void
     */
    public void scrollToWildCraft() {
        try {
            helper.jsScroll(HomePageLocator.clickWildCraftByte);
            helper.waitForElementToBeVisible(HomePageLocator.clickWildCraftByte, 5);
            
        } catch (Exception e) {
            LoggerHandler.error("Error clicking WildCraft: " + e.getMessage());
            test.fail("Error clicking WildCraft");
        }
    }
    public void clickWildCraft() {
    	helper.hoverOverElement(HomePageLocator.clickWildCraftByte);
        helper.jsClick(HomePageLocator.clickWildCraftByte);
    }

    /*
     * Method Name: bestSeller
     * Author Name: Naveen Kumar
     * Description: Verifies visibility of Best Seller products
     * Return type: void
     * Parameters: void
     */
    public void bestSeller() {
        try {
            helper.jsScroll(HomePageLocator.clickBestSellerBy);
            Thread.sleep(3000);
            helper.waitForElementToBeVisible(HomePageLocator.clickBestSellerBy, 5);
            helper.jsClick(HomePageLocator.clickBestSellerBy);
            int size = helper.getElementByXPath(HomePageLocator.getAllBSProductsBy);
            System.out.println(size);
            if (size > 0) {
                LoggerHandler.info("All products in Best Seller are visible");
                test.info("All products in Best Seller are visible");
            } else {
                LoggerHandler.info("All products in Best Seller are not visible");
                test.info("All products in Best Seller are not visible");
            }
        } catch (Exception e) {
            LoggerHandler.error("Error in bestSeller: " + e.getMessage());
            test.fail("Error in bestSeller");
        }
    }

    /*
     * Method Name: justIn
     * Author Name: Naveen Kumar
     * Description: Verifies visibility of Just In products
     * Return type: void
     * Parameters: void
     */
    public void justIn() {
        try {
            helper.jsScroll(HomePageLocator.clickJustInBy);
            Thread.sleep(3000);
            helper.waitForElementToBeVisible(HomePageLocator.clickJustInBy, 5);
            helper.jsClick(HomePageLocator.clickJustInBy);
            int size = helper.getElementByXPath(HomePageLocator.getAllBSProductsBy);
            System.out.println(size);
            if (size > 0) {
                LoggerHandler.info("All products in Just In are visible");
                test.info("All products in Just In are visible");
            } else {
                LoggerHandler.info("All products in Just In are not visible");
                test.info("All products in Just In are not visible");
            }
        } catch (Exception e) {
            LoggerHandler.error("Error in justIn: " + e.getMessage());
            test.fail("Error in justIn");
        }
    }

    /*
     * Method Name: exclusive
     * Author Name: Naveen Kumar
     * Description: Verifies visibility of Exclusive products and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void exclusive() {
        try {
            helper.jsScroll(HomePageLocator.clickExclusiveBy);
            Thread.sleep(3000);
            helper.waitForElementToBeVisible(HomePageLocator.clickExclusiveBy, 5);
            helper.jsClick(HomePageLocator.clickExclusiveBy);
            int size = helper.getElementByXPath(HomePageLocator.getAllBSProductsBy);
            System.out.println(size);
            if (size > 0) {
                LoggerHandler.info("All products in Exclusives are visible");
                test.info("All products in Exclusives are visible");
                Reporter.attachScreenShotToReport(test, driver, "All products are added");
                Screenshot.captureScreenshotTimeStamp(driver);
            } else {
                LoggerHandler.info("All products in Exclusives are not visible");
                test.info("All products in Exclusives are not visible");
                Screenshot.captureScreenshotTimeStamp(driver);
            }
        } catch (Exception e) {
            LoggerHandler.error("Error in exclusive: " + e.getMessage());
        }
    }
    /*
     * Method Name: validLogin
     * Author Name: Naveen Kumar
     * Description: Performs valid login using hardcoded credentials and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void clickLogin() {
    	try {
    		helper.hoverOverElement(HomePageLocator.hoverUserIcon);
            helper.hoverOverElement(HomePageLocator.clickLoginBy);
            helper.clickOnElement(HomePageLocator.clickLoginBy);
            Thread.sleep(3000);
		} catch (Exception e) {
			LoggerHandler.error("Error during valid login: " + e.getMessage());
            test.fail("Error during valid login");
            Reporter.attachScreenShotToReport(test,driver,"Valid login failed");
		}
    }

    /*
     * Method Name: clickDeliveryCharges
     * Author Name: Naveen Kumar
     * Description: Clicks on the delivery charges link
     * Return type: void
     * Parameters: void
     */
    public void clickDeliveryCharges() {
        try {
            helper.hoverOverElement(HomePageLocator.clickDeliverCharges);
            helper.clickOnElement(HomePageLocator.clickDeliverCharges);
            LoggerHandler.info("Clicked on Delivery Charges");
            test.info("Clicked on Delivery Charges");
        } catch (Exception e) {
            LoggerHandler.error("Error clicking Delivery Charges: " + e.getMessage());
            test.fail("Error clicking Delivery Charges");
            Reporter.attachScreenShotToReport(test,driver,"Click Delivery Charges failed");
        }
    }
    /*
     * Method Name: bestDeals
     * Author Name: Naveen Kumar
     * Description: Verifies visibility of bestDeals products and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void bestDeals() {
		try {
			helper.jsScroll(HomePageLocator.clickBestDealsBy);
			Thread.sleep(3000);
			helper.waitForElementToBeVisible(HomePageLocator.clickBestDealsBy, 5);
			helper.jsClick(HomePageLocator.clickBestDealsBy);
			
			int size=helper.getElementByXPath(HomePageLocator.getAllBSProductsBy);
			System.out.println(size);
			if(size>0) {
				LoggerHandler.info("All products in Best Deals is visible");
				test.info("All products in Best Deals is visible");
			}
			else {
				LoggerHandler.info("All products in Best Deals is not visible");
				test.info("All products in Best Deals is not visible");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
    /*
     * Method Name: clickMyOrders
     * Author Name: Naveen Kumar
     * Description: Clicks myOrder in the navbar
     * Return type: void
     * Parameters: void
     */
	public void clickMyOrders() {
		try {
			helper.hoverOverElement(HomePageLocator.hoverUserIcon);
			helper.hoverOverElement(HomePageLocator.myOrder);
			helper.clickOnElement(HomePageLocator.myOrder);
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
