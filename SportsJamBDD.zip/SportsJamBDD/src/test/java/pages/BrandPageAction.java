package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import uistore.BrandPageLocator;
import utility.LoggerHandler;
import utility.Reporter;
import utility.WebDriverHelper;

public class BrandPageAction {
    public static WebDriver driver;
    public static ExtentReports reports;
    public static ExtentTest test;
    public static WebDriverHelper helper;

    public BrandPageAction(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test = test;
        helper = new WebDriverHelper(driver);
    }

    /**
     * Method Name: clickNike
     * Author Name: Naveen Kumar
     * Description: Hover and click on Nike brand, then verify page title
     * Return type: void
     * Parameters: void
     */
    public void clickNike() {
        try {
            helper.hoverOverElement(BrandPageLocator.clickNikeBy);
            helper.waitForElementToBeVisible(BrandPageLocator.clickNikeBy, 10);
            helper.clickOnElement(BrandPageLocator.clickNikeBy);
            LoggerHandler.info("Clicked on Nike");
            test.info("Clicked on Nike");
            
        } catch (Exception e) {
            LoggerHandler.error("Error while clicking Nike brand: " + e.getMessage());
            test.fail("Error while clicking Nike brand.");
            Reporter.attachScreenShotToReport(test , driver ,"Nike brand click failed");
        }
    }public void verifyNike() {
    	try {
    		String titleString = driver.getTitle();
            helper.verify("Nike", titleString);
            test.info("Nike brand clicked and verified successfully.");
		} catch (Exception e) {
			LoggerHandler.error("Error while verifying Nike brand: " + e.getMessage());
            test.fail("Error while verifying Nike brand.");
            Reporter.attachScreenShotToReport(test , driver ,"Nike brand click failed");
		}
    }

    /**
     * Method Name: clickAlpha
     * Author Name: Naveen Kumar
     * Description: Click on Alpha and Adidas brand, then verify page title
     * Return type: void
     * Parameters: void
     */
    public void clickAlpha() {
        try {
//            helper.clickOnElement(BrandPageLocator.clickABy);
            helper.hoverOverElement(BrandPageLocator.clickAdidasBy);
            helper.clickOnElement(BrandPageLocator.clickAdidasBy);
        } catch (Exception e) {
            LoggerHandler.error("Error while clicking Alpha/Adidas brand: " + e.getMessage());
            test.fail("Error while clicking Alpha/Adidas brand.");
            Reporter.attachScreenShotToReport(test,driver,"Alpha/Adidas brand click failed");
        }
    }
    public void verifyAlpha() {
    	try {
    		String titleString = driver.getTitle();
            helper.verify("Adidas", titleString);
            test.info("Alpha and Adidas brands clicked and verified successfully.");
		} catch (Exception e) {
			LoggerHandler.error("Error while verifying Alpha/Adidas brand: " + e.getMessage());
            test.fail("Error while verifying Alpha/Adidas brand.");
            Reporter.attachScreenShotToReport(test,driver,"Alpha/Adidas brand verify failed");
		}
    }
    public void clickA() {
    	helper.clickOnElement(BrandPageLocator.clickABy);
    }

    /**
     * Method Name: clickNumeric
     * Author Name: Naveen Kumar
     * Description: Click on numeric brand and verify error message
     * Return type: void
     * Parameters: void
     */
    public void clickNumeric() {
        try {
            helper.clickOnElement(BrandPageLocator.clickNumBy);
            
        } catch (Exception e) {
            LoggerHandler.error("Error while clicking Numeric brand: " + e.getMessage());
            test.fail("Error while clicking Numeric brand.");
            Reporter.attachScreenShotToReport(test,driver,"Numeric brand click failed");
        }
    }
    public void verifyNumberic() {
    	try {
    		String txtString = driver.findElement(BrandPageLocator.verifyErrorBy).getText();
            helper.verify("CAN'T FIND", txtString);
            test.info("Numeric brand clicked and error message verified.");
		} catch (Exception e) {
			LoggerHandler.error("Error while verifying Numeric brand: " + e.getMessage());
            test.fail("Error while verifying Numeric brand.");
            Reporter.attachScreenShotToReport(test,driver,"Numeric brand verify failed");
		}
    }

    /**
     * Method Name: wildCraft
     * Author Name: Naveen Kumar
     * Description: Verify Wildcraft brand page title
     * Return type: void
     * Parameters: void
     */
    public void wildCraft() {
        try {
            String titleString = driver.getTitle();
            helper.verify("Wildcraft", titleString);
            test.info("Wildcraft brand page title verified.");
        } catch (Exception e) {
            LoggerHandler.error("Error while verifying Wildcraft brand: " + e.getMessage());
            test.fail("Error while verifying Wildcraft brand.");
            Reporter.attachScreenShotToReport(test,driver,"Wildcraft brand verification failed");
        }
    }
}
