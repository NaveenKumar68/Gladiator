package utility;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
    /*
     * Method Name: captureScreenshotTimeStamp
     * Author Name: Swagat Das
     * Description: Captures a screenshot of the current browser window and saves it
     * with a timestamp in the screenshots directory.
     * Return type: void
     * Parameters: WebDriver driver
     */

    public static void captureScreenshotTimeStamp(WebDriver driver) {
        try {
            String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss.").format(new Date());
            File dir = new File("./screenshots");
            if (!dir.exists()) {
                dir.mkdir();
            }
            File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File("./screenshots/" + timestamp + ".png");
            Files.copy(scr.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Method Name: captureScreenshotTimeStampAndName
     * Author Name: Swagat Das
     * Description: Captures a screenshot of the current browser window and saves it
     * with a timestamp and name in the screenshots directory.
     * Return type: void
     * Parameters: WebDriver driver,String name
     */
    public static void captureScreenshotTimeStampAndName(WebDriver driver, String name) {
        try {
            String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss.").format(new Date());
            File dir = new File("./screenshots");
            if (!dir.exists()) {
                dir.mkdir();
            }
            File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File("./screenshots/" + name + "(" + timestamp + ")" + ".png");
            Files.copy(scr.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Method Name: captureScreenshotNameReport
     * Author Name: Swagat Das
     * Description: Capture Screenshot and attach it to the Report
     * Return type: void
     * Parameters: WebDriver driver, String name
     */
    public static void captureScreenshotNameReport(WebDriver driver, String name) {
        try {
            File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File("./reports/" + name + ".png");
            Files.copy(scr.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
