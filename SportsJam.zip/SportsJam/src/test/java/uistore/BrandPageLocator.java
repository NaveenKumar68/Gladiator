package uistore;

import org.openqa.selenium.By;

public class BrandPageLocator {
	public static By clickNikeBy=By.xpath("((//div[@class='item'])[23]/div/a)[2]");
	//testcase4
	public static By clickABy=By.xpath("//div[@class='characters']/ul/li[2]");
	public static By clickAdidasBy=By.xpath("(//div[@class='item'])[2]");
	//TestCase5
	public static By clickNumBy=By.xpath("//div[@class='characters']/ul/li[1]");
	public static By verifyErrorBy=By.xpath("//div[@class='message info empty']/div");
}

