package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import uistore.DeliveryInformationPageLocator;
import utility.LoggerHandler;
import utility.Reporter;
import utility.Screenshot;
import utility.WebDriverHelper;

public class DeliveryInformationPageAction {
    public static WebDriver driver;
    public static ExtentReports reports;
    public static ExtentTest test;
    public static WebDriverHelper helper;

    /**
     * Constructor to initialize WebDriver and ExtentTest instances.
     * @param driver WebDriver instance
     * @param test ExtentTest instance for reporting
     */
    public DeliveryInformationPageAction(WebDriver driver, ExtentTest test) {
        DeliveryInformationPageAction.driver = driver;
        DeliveryInformationPageAction.test = test;
        helper = new WebDriverHelper(driver);
    }

    /*
     * Method Name: deliveryChart
     * Author Name: Naveen Kumar
     * Description: Verifies delivery chart element and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void deliveryChart() {
        try {
            helper.getElementByXPath(DeliveryInformationPageLocator.verifyChart);
            Screenshot.captureScreenshotTimeStamp(driver);
            test.info("Delivery chart verified and screenshot captured.");
        } catch (Exception e) {
            LoggerHandler.error("Error verifying delivery chart: " + e.getMessage());
            test.fail("Error verifying delivery chart.");
            Reporter.attachScreenShotToReport(test,driver,"Delivery chart verification failed");
        }
    }

    /*
     * Method Name: clickBlueDart
     * Author Name: Naveen Kumar
     * Description: Clicks on Blue Dart link, switches window, and captures screenshot
     * Return type: void
     * Parameters: void
     */
    public void clickBlueDart() {
        try {
            helper.clickOnElement(DeliveryInformationPageLocator.clickBlueDartBy);
            helper.switchWin();
            Screenshot.captureScreenshotTimeStamp(driver);
            test.info("Clicked on Blue Dart and switched window successfully.");
        } catch (Exception e) {
            LoggerHandler.error("Error clicking Blue Dart: " + e.getMessage());
            test.fail("Error clicking Blue Dart.");
            Reporter.attachScreenShotToReport(test,driver,"Blue Dart click failed");
        }
    }
}
