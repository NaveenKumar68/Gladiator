package runner;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.BrandPageAction;
import pages.DeliveryInformationPageAction;
import pages.HomePageAction;
import pages.LoginPageAction;
import utility.Base;
import utility.Reporter;

public class TestRunner extends Base{
	public static ExtentReports reports;
	public static ExtentTest test;
	@BeforeSuite
	void createReport() {
		reports=Reporter.generateExtentReport("Sports_Jam_Report");
	}
	@BeforeMethod
	void setUp() {
		openBrowser();
	}
	@Test
	void test1() {
		test=reports.createTest("TestCase1");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.locateSearchBar();
		hPageAction.clickSearchBtn1();
		hPageAction.verify();
	}
	@Test
	void test2() {
		test=reports.createTest("TestCase2");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.locateSearchBar();
		hPageAction.clickSearchBtn2();
	}
	@Test
	void test3() {
		test=reports.createTest("TestCase3");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		BrandPageAction bPageAction=new BrandPageAction(driver, test);
		hPageAction.clickBrand();
		bPageAction.clickNike();
	}
	@Test
	void test4() {
		test=reports.createTest("TestCase4");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		BrandPageAction bPageAction=new BrandPageAction(driver, test);
		hPageAction.clickBrand();
		bPageAction.clickAlpha();
	}
	@Test
	void test5() {
		test=reports.createTest("TestCase5");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		BrandPageAction bPageAction=new BrandPageAction(driver, test);
		hPageAction.clickBrand();
		bPageAction.clickNumeric();
	}
	@Test
	void test6() {
		test=reports.createTest("TestCase6");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		BrandPageAction bPageAction=new BrandPageAction(driver, test);
		hPageAction.clickWildCraft();
		bPageAction.wildCraft();
	}
	@Test
	void test7() {
		test=reports.createTest("TestCase7");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.bestSeller();
	}
	@Test
	void test8() {
		test=reports.createTest("TestCase8");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.justIn();
	}
	@Test
	void test9() {
		test=reports.createTest("TestCase9");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.exclusive();
	}
	@Test
	void test10() {
		test=reports.createTest("TestCase10");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		hPageAction.bestDeals();
	}
	@Test
	void test11() {
		test=reports.createTest("TestCase11");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		LoginPageAction lPageAction=new LoginPageAction(driver, test);
		hPageAction.clickLogin();
		lPageAction.validLogin();
		hPageAction.clickMyOrders();
	}
	@Test
	void test12() {
		test=reports.createTest("TestCase12");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		LoginPageAction lPageAction=new LoginPageAction(driver, test);
		hPageAction.clickLogin();
		lPageAction.inValidLogin();
		hPageAction.clickMyOrders();
	}
	@Test
	void test13() {
		test=reports.createTest("TestCase13");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		DeliveryInformationPageAction dPageAction=new DeliveryInformationPageAction(driver, test);
		hPageAction.clickDeliveryCharges();
		dPageAction.deliveryChart();
	}
	@Test
	void test14() {
		test=reports.createTest("TestCase14");
		HomePageAction hPageAction=new HomePageAction(driver, test);
		DeliveryInformationPageAction dPageAction=new DeliveryInformationPageAction(driver, test);
		hPageAction.clickDeliveryCharges();
		dPageAction.clickBlueDart();
	}
	@AfterMethod
	void destroy() {
		if(driver!=null) {
			driver.quit();
		}
	}
	@AfterSuite
	void flu() {
		if(reports!=null) {
			reports.flush();
		}
	}
}
